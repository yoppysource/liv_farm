enum BottomSheetType {
  Basic,
  storeSelection,
  AddToCart,
  Write,
  GetDateTime,
  GetGender,
  CustomerService,
  Review,
  ChangePassword,
  PointInput,
}
