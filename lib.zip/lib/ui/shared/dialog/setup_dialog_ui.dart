import 'package:flutter/material.dart';
import 'package:liv_farm/app/app.locator.dart';
import 'package:stacked_services/stacked_services.dart';

enum DialogType { basic, form }
void setupDialogUi() {
  var dialogService = locator<DialogService>();
}
