enum dialogType { Basic, Form }
