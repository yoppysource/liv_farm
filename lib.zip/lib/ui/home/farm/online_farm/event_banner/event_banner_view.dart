import 'package:liv_farm/app/app.locator.dart';
import 'package:liv_farm/services/server_service/api_exception.dart';
import 'package:liv_farm/services/server_service/client_service.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

class EventBannerViewModel extends FutureViewModel {
  List? eventsDataList;
  final ClientService _serverService = locator<ClientService>();
  final DialogService _dialogService = locator<DialogService>();
  int pageIndex = 0;
  @override
  Future<void> futureToRun() async {
    eventsDataList = await _serverService.sendRequest(
        method: HttpMethod.get, resource: Resource.events);
  }

  @override
  void onError(error) {
    if (error is APIException) {
      _dialogService.showDialog(title: "오류", description: error.message);
    } else {
      throw error;
    }
  }

  void setPageIndex(int index) {
    pageIndex = index;
    notifyListeners();
  }
}
