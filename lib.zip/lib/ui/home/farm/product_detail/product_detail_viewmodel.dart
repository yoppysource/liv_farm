import 'dart:async';
import 'package:flutter/material.dart';
import 'package:liv_farm/app/app.locator.dart';
import 'package:liv_farm/app/app.router.dart';
import 'package:liv_farm/model/inventory.dart';
import 'package:liv_farm/model/product.dart';
import 'package:liv_farm/model/review.dart';
import 'package:liv_farm/services/analytics_service.dart';
import 'package:liv_farm/services/cart_provider_service.dart';
import 'package:liv_farm/services/server_service/api_exception.dart';
import 'package:liv_farm/services/server_service/client_service.dart';
import 'package:liv_farm/services/store_provider_service.dart';
import 'package:liv_farm/services/toast_service.dart';
import 'package:liv_farm/services/user_provider_service.dart';
import 'package:liv_farm/ui/shared/bottom_sheet/bottom_sheet_type.dart';
import 'package:liv_farm/util/category_enum.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

class ProductDetailViewModel extends FutureViewModel {
  Inventory inventory;
  late Product product;
  final BottomSheetService _bottomSheetService = locator<BottomSheetService>();
  final DialogService _dialogService = locator<DialogService>();
  final ClientService _serverService = locator<ClientService>();
  final UserProviderService _userProviderService =
      locator<UserProviderService>();
  final AnalyticsService _analyticsService = locator<AnalyticsService>();
  final NavigationService _navigationService = locator<NavigationService>();
  final CartProviderService _cartProviderService =
      locator<CartProviderService>();
  final StoreProviderService _storeProviderService =
      locator<StoreProviderService>();

  ProductDetailViewModel({required this.inventory});

  @override
  Future<void> futureToRun() async {
    try {
      Map<String, dynamic> data =
          await _serverService.sendRequest<Map<String, dynamic>>(
              method: HttpMethod.get,
              resource: Resource.products,
              endPath: '/${inventory.product.id}');
      product = Product.fromJson(data);
    } catch (e) {
      print(e);
      ToastMessageService.showToast(message: "상품정보를 가져오는데 실패하였습니다.");
    }
  }

  void onBackPressed() {
    _navigationService.back();
  }

  Future<void> onTapForReport(Review review) async {
    try {
      dynamic data = await _serverService.sendRequest(
          method: HttpMethod.patch,
          resource: Resource.products,
          endPath: '/${product.id}/reviews/${review.id}/report',
          data: {});
      print(data);
      ToastMessageService.showToast(message: '신고가 정상적으로 접수되었습니다.');
    } on APIException catch (e) {
      ToastMessageService.showToast(message: e.message);
    } catch (e) {
      print(e.toString());
      ToastMessageService.showToast(message: "오류가 발생했습니다");
    }
  }

  Future<void> addToCart(
      {required String inventoryId, required int quantity}) async {
    try {
      Map<String, dynamic> data = await _serverService.sendRequest(
          method: HttpMethod.post,
          resource: Resource.carts,
          data: {'inventory': inventoryId, 'quantity': quantity},
          endPath: '/my/item');
      _cartProviderService.syncCartFromJson(data);

      ToastMessageService.showToast(message: '장바구니에 담았습니다');
    } on APIException catch (e) {
      await _dialogService.showDialog(
          title: '오류',
          description: e.message,
          barrierDismissible: true,
          buttonTitle: '확인');
    } catch (e) {
      await _dialogService.showDialog(
          title: '오류',
          description: "오류가 발생했습니다",
          barrierDismissible: true,
          buttonTitle: '확인');
    }
    notifyListeners();
  }

  Future<void> onCartTap() async {
    if (!_userProviderService.isLogined) {
      DialogResponse? _dialogResponse =
          await _dialogService.showConfirmationDialog(
        title: '로그인이 필요합니다',
        description: '로그인 또는 회원가입을 하시겠습니까?',
        cancelTitle: '취소',
        confirmationTitle: '로그인하기',
        barrierDismissible: true,
      );
      if (_dialogResponse != null && _dialogResponse.confirmed)
        _navigationService.navigateTo(Routes.loginView);
      return;
    }
    SheetResponse? sheetResponse = await _bottomSheetService.showCustomSheet(
      isScrollControlled: true,
      variant: BottomSheetType.AddToCart,
      data: {
        'inventoryList': [inventory]
      },
    );
    if (sheetResponse != null && sheetResponse.confirmed) {
      sheetResponse.responseData.forEach((Inventory k, int v) async {
        if (v > 0) {
          await _analyticsService.logAddCart(
              id: k.id,
              productName: k.product.name,
              productCategory: k.product.category.toString(),
              quantity: v);
          await addToCart(inventoryId: k.id, quantity: v);
        }
      });
    }
    if (product.category == ProductCategory.salad &&
        sheetResponse != null &&
        sheetResponse.confirmed) {
      SheetResponse? sheetResponseForProtein =
          await _bottomSheetService.showCustomSheet(
        isScrollControlled: true,
        variant: BottomSheetType.AddToCart,
        data: {
          // 'inventoryList': _storeProviderService
          //     .inventoryMapByCategory[ProductCategory.Protein],
          'needDetailArrow': true,
        },
      );
      if (sheetResponseForProtein != null &&
          sheetResponseForProtein.confirmed) {
        sheetResponseForProtein.responseData
            .forEach((Inventory k, int v) async {
          if (v > 0) {
            await _analyticsService.logAddCart(
                id: k.id,
                productName: k.product.name,
                productCategory: k.product.category.toString(),
                quantity: v);
            await addToCart(inventoryId: k.id, quantity: v);
          } else {
            return;
          }
        });
      }

      SheetResponse? sheetResponseForDressing =
          await _bottomSheetService.showCustomSheet(
        isScrollControlled: true,
        variant: BottomSheetType.AddToCart,
        data: {
          // 'inventoryList': _storeProviderService
          //     .inventoryMapByCategory[ProductCategory.Dressing],
          'needDetailArrow': true,
        },
      );

      if (sheetResponseForDressing != null &&
          sheetResponseForDressing.confirmed) {
        sheetResponseForDressing.responseData
            .forEach((Inventory k, int v) async {
          if (v > 0) {
            await _analyticsService.logAddCart(
                id: k.id,
                productName: k.product.name,
                productCategory: k.product.category.toString(),
                quantity: v);
            await addToCart(inventoryId: k.id, quantity: v);
          }
        });
      }
    }
    if (sheetResponse != null && sheetResponse.confirmed) {
      _navigationService.back();
    }
  }
}
