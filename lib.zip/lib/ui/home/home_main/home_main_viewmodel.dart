import 'package:liv_farm/app/app.locator.dart';
import 'package:liv_farm/model/store.dart';
import 'package:liv_farm/services/store_provider_service.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

class HomeMainViewModel extends BaseViewModel {
  final StoreProviderService _storeProviderService =
      locator<StoreProviderService>();
  final DialogService _dialogService = locator<DialogService>();
  Store get store => _storeProviderService.store!;

  Future<void> onPressForChangingStore() async {
    await _storeProviderService.selectShopByBottomSheet();
    notifyListeners();
  }

  void onTapForInformation() async {
    _dialogService.showDialog(
        title: '상점정보',
        description:
            '주소${store.address}\n운영시간: ${store.openHourStr} ~ ${store.closeHourStr}\n휴일: 일요일',
        barrierDismissible: true,
        buttonTitle: '확인');
  }
}
