import 'package:flutter/material.dart';
import 'package:flutter_html/shims/dart_ui_real.dart';
import 'package:liv_farm/ui/home/farm/online_farm/event_banner/event_banner_viewmodel.dart';
import 'package:liv_farm/ui/home/home_main/home_main_viewmodel.dart';
import 'package:liv_farm/ui/shared/information_about_company_card.dart';
import 'package:liv_farm/ui/shared/store_card.dart';
import 'package:liv_farm/ui/shared/styles.dart';
import 'package:stacked/stacked.dart';

class HomeMainView extends StatelessWidget {
  const HomeMainView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    return ViewModelBuilder<HomeMainViewModel>.reactive(
      builder: (context, model, child) =>
          LayoutBuilder(builder: (context, constraint) {
        final eventBannerHeight = constraint.maxHeight * 0.45;
        return Scaffold(
          body: Stack(
            children: <Widget>[
              SizedBox(
                height: eventBannerHeight,
                width: double.infinity,
                child: const EventBannerView(),
              ),
              DraggableScrollableSheet(
                initialChildSize: 0.60,
                minChildSize: 0.60,
                expand: true,
                builder:
                    (BuildContext context, ScrollController scrollController) {
                  return SingleChildScrollView(
                    controller: scrollController,
                    child: Container(
                      decoration: BoxDecoration(
                          color: Theme.of(context).scaffoldBackgroundColor,
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(30.0),
                            topRight: Radius.circular(30.0),
                          )),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 25),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            verticalSpaceLarge,
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text(
                                  '안녕하세요,\n${model.store.name}입니다',
                                  textAlign: TextAlign.left,
                                  style: Theme.of(context).textTheme.subtitle2,
                                ),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    GestureDetector(
                                      onTap: () {
                                        showDialog(
                                            context: context,
                                            builder: (context) => Dialog(
                                                  backgroundColor:
                                                      Colors.transparent,
                                                  child: SizedBox(
                                                    height:
                                                        constraint.maxHeight *
                                                            0.25,
                                                    child: Stack(
                                                      children: [
                                                        StoreCard(
                                                          store: model.store,
                                                          radius: 5.0,
                                                        ),
                                                        Positioned(
                                                          child:
                                                              GestureDetector(
                                                            child: Text(
                                                              '확인',
                                                              style: textTheme
                                                                  .bodyText1!
                                                                  .copyWith(
                                                                      color: Colors
                                                                          .blueAccent),
                                                            ),
                                                            onTap: Navigator.of(
                                                                    context)
                                                                .pop,
                                                          ),
                                                          bottom: 15,
                                                          right: 20,
                                                        )
                                                      ],
                                                    ),
                                                  ),
                                                ));
                                      },
                                      child: const Icon(
                                        Icons.info_outline,
                                        color: kDelightPink,
                                        size: 32,
                                      ),
                                    ),
                                    horizontalSpaceRegular,
                                    ActionChip(
                                      onPressed: () async =>
                                          await model.onPressForChangingStore(),
                                      materialTapTargetSize:
                                          MaterialTapTargetSize.shrinkWrap,
                                      backgroundColor: kDelightPink,
                                      label: Text(
                                        '매장변경',
                                        style: Theme.of(context)
                                            .textTheme
                                            .bodyText2!
                                            .copyWith(color: Colors.white),
                                      ),
                                    ),
                                  ],
                                )
                              ],
                            ),
                            verticalSpaceLarge,
                            Text(
                              '정기구독 서비스',
                              textAlign: TextAlign.left,
                              style: Theme.of(context).textTheme.subtitle2,
                            ),
                            verticalSpaceSmall,
                            Text(
                              '매일 만나는 신선함, 매일 만나는 신선함, 매일 만나는 신선함, 매일 만나는 신선함, 매일 만나는 신선함 ',
                              textAlign: TextAlign.left,
                              style: Theme.of(context).textTheme.bodyText2,
                            ),
                            verticalSpaceRegular,
                            Container(
                              height: 150,
                              decoration: BoxDecoration(
                                  color: kMainColor.withOpacity(0.6),
                                  borderRadius: const BorderRadius.all(
                                    Radius.circular(5.0),
                                  )),
                            ),
                            verticalSpaceRegular,
                            Container(
                              height: 150,
                              decoration: BoxDecoration(
                                  color: kMainColor.withOpacity(0.6),
                                  borderRadius: const BorderRadius.all(
                                    Radius.circular(5.0),
                                  )),
                            ),
                            verticalSpaceRegular,
                            Container(
                              height: 150,
                              decoration: BoxDecoration(
                                  color: kMainColor.withOpacity(0.6),
                                  borderRadius: const BorderRadius.all(
                                    Radius.circular(5.0),
                                  )),
                            ),
                            verticalSpaceLarge,
                            Text(
                              '오늘의 상품',
                              textAlign: TextAlign.left,
                              style: Theme.of(context).textTheme.subtitle2,
                            ),
                            verticalSpaceSmall,
                            Text(
                              '오늘의 상품은 가장 신선함.오늘의 상품은 가장 신선함.오늘의 상품은 가장 신선함.오늘의 상품은 가장 신선함.',
                              textAlign: TextAlign.left,
                              style: Theme.of(context).textTheme.bodyText2,
                            ),
                            verticalSpaceRegular,
                            SizedBox(
                              height: 150,
                              child: ListView(
                                scrollDirection: Axis.horizontal,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(right: 10),
                                    child: Container(
                                      width: 150,
                                      decoration: BoxDecoration(
                                        color: kDelightPink.withOpacity(0.8),
                                        borderRadius: const BorderRadius.all(
                                          Radius.circular(5.0),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(right: 10),
                                    child: Container(
                                      width: 150,
                                      decoration: BoxDecoration(
                                        color: kDelightPink.withOpacity(0.8),
                                        borderRadius: const BorderRadius.all(
                                          Radius.circular(5.0),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(right: 10),
                                    child: Container(
                                      width: 150,
                                      decoration: BoxDecoration(
                                        color: kDelightPink.withOpacity(0.8),
                                        borderRadius: const BorderRadius.all(
                                          Radius.circular(5.0),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            verticalSpaceLarge,
                            Column(
                              children: const [
                                InnerText(
                                  title: '(주)퓨처커넥트',
                                  content: '',
                                ),
                                SizedBox(
                                  height: 8,
                                ),
                                InnerText(
                                  title: '대표자',
                                  content: '강길모',
                                ),
                                InnerText(
                                  title: '사업자등록번호',
                                  content: '801-81-01885',
                                ),
                                InnerText(
                                  title: '통신판매업신고번호',
                                  content: '제2021-서울강남-00617호',
                                ),
                                InnerText(
                                  title: '배송기간',
                                  content: '즉시배송',
                                ),
                                InnerText(
                                  title: '주소',
                                  content: '서울특별시 강남구 테헤란로63길 14, 12층',
                                ),
                                InnerText(
                                  title: '대표전화',
                                  content: '02 6081 8179',
                                ),
                                InnerText(
                                  title: '이메일',
                                  content: 'admin@livfarm.com',
                                ),
                                InnerText(
                                  title: '홈페이지',
                                  content: 'www.livfarm.com',
                                ),
                              ],
                            ),
                            verticalSpaceLarge,
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        );
      }),
      viewModelBuilder: () => HomeMainViewModel(),
    );
  }
}
