import 'dart:async';
import 'package:iamport_flutter/model/payment_data.dart';
import 'package:liv_farm/app/app.locator.dart';
import 'package:liv_farm/app/app.router.dart';
import 'package:liv_farm/model/address.dart';
import 'package:liv_farm/model/cart.dart';
import 'package:liv_farm/model/coupon.dart';
import 'package:liv_farm/model/order.dart';
import 'package:liv_farm/model/store.dart';
import 'package:liv_farm/services/cart_provider_service.dart';
import 'package:liv_farm/services/in_offine_store_service.dart';
import 'package:liv_farm/services/server_service/api_exception.dart';
import 'package:liv_farm/services/server_service/client_service.dart';
import 'package:liv_farm/services/store_provider_service.dart';
import 'package:liv_farm/services/toast_service.dart';
import 'package:liv_farm/services/user_provider_service.dart';
import 'package:liv_farm/ui/home/shopping_cart/address_select/address_select_view.dart';
import 'package:liv_farm/ui/home/shopping_cart/purchase/purchase_option_view.dart';
import 'package:liv_farm/ui/home/shopping_cart/purchase/purchase_view.dart';
import 'package:liv_farm/ui/shared/bottom_sheet/bottom_sheet_type.dart';
import 'package:liv_farm/ui/shared/bottom_sheet/pick_date_time_bottom_sheet/pick_date_time_bottom_sheet_viewmodel.dart';
import 'package:liv_farm/util/delivery_reservation_caluator.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

class ShoppingCartViewModel extends ReactiveViewModel {
  final UserProviderService _userProviderService =
      locator<UserProviderService>();
  final DialogService _dialogService = locator<DialogService>();
  final BottomSheetService _bottomSheetService = locator<BottomSheetService>();
  final NavigationService _navigationService = locator<NavigationService>();
  final CartProviderService _cartProviderService =
      locator<CartProviderService>();
  final ClientService _serverService = locator<ClientService>();
  final StoreProviderService _storeProviderService =
      locator<StoreProviderService>();
  final InOffineStoreService _inOffineStoreService =
      locator<InOffineStoreService>();
  @override
  List<ReactiveServiceMixin> get reactiveServices => [_cartProviderService];
  final DateTime _now = DateTime.now();

  late DeliveryReservationCaluator _caluator;

  Store? get store => _storeProviderService.store;
  bool get takeOut => store!.takeOut && _cartProviderService.takeout;
  bool get showBannerText => _userProviderService.user!.addresses!.isNotEmpty;
  int get availablePoint => _userProviderService.user!.point;
  bool get isOffineMode => _inOffineStoreService.isOffineMode;
  int pointInput = 0;
  String get bannerText {
    if (impossibleToBuyBasedOnLocation && isOffineMode != true) {
      return "배송이 불가능한 지역입니다";
    } else {
      return "${_storeProviderService.store!.name}에서 수확합니다";
    }
  }

  bool get impossibleToBuyBasedOnLocation =>
      // _storeProviderService.isPossibleToBuy == false &&
      _userProviderService.user!.addresses!.isNotEmpty;

  Address? get selectedAddress =>
      _userProviderService.user!.addresses!.isNotEmpty
          ? _userProviderService.user!.addresses![0]
          : null;
  //About Cart
  Cart get cart => _cartProviderService.cart!;
  int get cartLength => cart.items!.length;
  String get deliveryRequestMessage => _cartProviderService.orderRequestMessage;
  Coupon? get selectedCoupon => _cartProviderService.selectedCoupon;

  String get bookingOrderMessage {
    String message = '';
    if (_cartProviderService.bookingOrderDateTime == null) {
      if (_caluator.isPossibleToBuyNow(_now)) {
        message = "주문 후 바로 수확하여 30분 내로 받기";
      } else if (_caluator.dateTimePairedWithTimeOfDayList!.keys.first.day ==
          _now.day) {
        message = "오늘 ${_caluator.openHourOnApp}시에 받기";
      } else {
        message =
            "${_caluator.dateTimePairedWithTimeOfDayList!.keys.first.day}일 (${_caluator.getWeekDaysName(_caluator.dateTimePairedWithTimeOfDayList!.keys.first)}) ${_caluator.openHourOnApp}시에 받기";
      }
    } else {
      message =
          "${_cartProviderService.bookingOrderDateTime!.day}일(${_caluator.getWeekDaysName(_cartProviderService.bookingOrderDateTime!)}) ${_cartProviderService.bookingOrderDateTime!.hour}시${_cartProviderService.bookingOrderDateTime!.minute == 0 ? '' : " " + _cartProviderService.bookingOrderDateTime!.minute.toString() + '분'}에 받기";
    }
    return message;
  }

  ShoppingCartViewModel() {
    _caluator = DeliveryReservationCaluator(
      _now,
      false,
      false,
      store!.isOpenToday,
      store!.openHourStr,
      store!.closeHourStr,
    );
  }

  int get totalPrice {
    int price = 0;
    if (cart!.items!.isEmpty) return 0;
    for (var item in cart!.items!) {
      price += item.inventory.product.price * item.quantity;
    }
    return price;
  }

  int get discountAmount {
    return totalPrice - finalPrice;
  }

  int get finalPrice {
    return _totalDiscountedPriceIncludePoint - _couponDiscountAmount;
  }

  int get _totalDiscountedPrice {
    int price = 0;
    if (cart!.items!.isEmpty) return 0;
    cart!.items!.forEach((item) =>
        price += item.inventory.product.discountedPrice! * item.quantity);
    return price;
  }

  int get _totalDiscountedPriceIncludePoint {
    if (_totalDiscountedPrice < pointInput) return _totalDiscountedPrice;
    return _totalDiscountedPrice - pointInput;
  }

  int get _couponDiscountAmount {
    if (_cartProviderService.selectedCoupon != null &&
        _cartProviderService.selectedCoupon!.amount <
            _totalDiscountedPriceIncludePoint) {
      return _cartProviderService.selectedCoupon!.amount;
    } else {
      return 0;
    }
  }

  bool get isCouponAmountExceedDiscountedPrice =>
      (_cartProviderService.selectedCoupon != null &&
          _cartProviderService.selectedCoupon!.amount >
              _totalDiscountedPriceIncludePoint);

  bool get isInputPointAmountExceedDiscountedPrice =>
      (pointInput != 0 && pointInput >= _totalDiscountedPrice);
  void onPressedDeliveryOption(bool takeout) {
    if (_cartProviderService.takeout != takeout) {
      _cartProviderService.takeout = takeout;
      notifyListeners();
    }
  }

  Future<void> increaseItemQuantity(Item item) async {
    try {
      if (item.inventory.inventory > item.quantity) {
        item.quantity += 1;
        notifyListeners();
        Map<String, dynamic> data = await _serverService.sendRequest(
            method: HttpMethod.patch,
            resource: Resource.carts,
            endPath: '/my/item',
            data: item.toJson());
        _cartProviderService.syncCartFromJson(data);
        notifyListeners();
      } else {
        ToastMessageService.showToast(message: "재고가 부족합니다");
      }
    } on APIException catch (e) {
      _dialogService.showDialog(
          title: '오류',
          description: e.message.toString(),
          barrierDismissible: true,
          buttonTitle: '확인');
    } catch (e) {
      _dialogService.showDialog(
          title: '오류',
          description: e.toString(),
          barrierDismissible: true,
          buttonTitle: '확인');
    }
  }

  Future<void> decreaseItemQuantity(Item item) async {
    try {
      item.quantity -= 1;
      notifyListeners();
      Map<String, dynamic> data = await _serverService.sendRequest(
          method: HttpMethod.patch,
          resource: Resource.carts,
          endPath: '/my/item',
          data: item.toJson());
      _cartProviderService.syncCartFromJson(data);
      notifyListeners();
    } on APIException catch (e) {
      _dialogService.showDialog(
          title: '오류',
          description: e.message.toString(),
          barrierDismissible: true,
          buttonTitle: '확인');
    } catch (e) {
      _dialogService.showDialog(
          title: '오류',
          description: "오류가 발생했습니다.",
          barrierDismissible: true,
          buttonTitle: '확인');
    }
  }

  Future<void> removeFromCart(Item item) async {
    try {
      cart.items!.remove(item);
      notifyListeners();
      Map<String, dynamic> data = await _serverService.sendRequest(
          method: HttpMethod.post,
          resource: Resource.carts,
          endPath: '/my/item/delete',
          data: item.toJson());
      _cartProviderService.syncCartFromJson(data);
      notifyListeners();
    } on APIException catch (e) {
      _dialogService.showDialog(
          title: '오류',
          description: e.message.toString(),
          barrierDismissible: true,
          buttonTitle: '확인');
    } catch (e) {
      _dialogService.showDialog(
          title: '오류',
          description: "오류가 발생했습니다.",
          barrierDismissible: true,
          buttonTitle: '확인');
    }
    notifyListeners();
  }

  Future<void> onPressPointInput() async {
    // if (this.availablePoint <= 1000) {
    //   return _dialogService.showDialog(
    //       title: '오류',
    //       description: "포인트는 1000점 이상부터 사용 가능합니다.",
    //       buttonTitle: '확인');
    // }
    pointInput = 0;
    SheetResponse? _sheetResponse = await _bottomSheetService.showCustomSheet(
        isScrollControlled: true,
        variant: BottomSheetType.PointInput,
        data: {"availablePoint": availablePoint},
        title: '사용가능 포인트: $availablePoint점');
    if (_sheetResponse != null && _sheetResponse.confirmed) {
      pointInput = _sheetResponse.responseData['pointInput'];
    }
    notifyListeners();
  }

  Future<void> callBottomSheetToGetInput() async {
    SheetResponse? _sheetResponse = await _bottomSheetService.showCustomSheet(
        isScrollControlled: true,
        variant: BottomSheetType.Write,
        data: {
          'maxLength': 50,
          'text': _cartProviderService.orderRequestMessage,
        },
        title: '요청사항');
    if (_sheetResponse != null && _sheetResponse.confirmed) {
      _cartProviderService.orderRequestMessage =
          _sheetResponse.responseData['input'];
    }
    notifyListeners();
  }

  Future callBottomSheetToGetDateTime() async {
    if (isBusy == true) return;
    _cartProviderService.bookingOrderDateTime = null;
    SheetResponse? _sheetResponse = await _bottomSheetService.showCustomSheet(
        isScrollControlled: true,
        variant: BottomSheetType.GetDateTime,
        title: bookingOrderMessage,
        data: _caluator.dateTimePairedWithTimeOfDayList);
    if (_sheetResponse != null && _sheetResponse.confirmed) {
      print(_sheetResponse.responseData.toString());
      _cartProviderService.bookingOrderDateTime = _sheetResponse
          .responseData[PickDateTimeBottomSheetViewModel.KEY_selectedDate];
      notifyListeners();
    }
  }

  Future<void> onPressedCouponSelect() async {
    await _navigationService.navigateTo(Routes.couponView);
    notifyListeners();
  }

  Future<void> onPressedAddress() async {
    _inOffineStoreService.isOffineMode
        ? _dialogService.showDialog(
            title: '배송지',
            description: "매장 내 스캔을 하실 때는 사용할 수 없는 기능입니다.",
            buttonTitle: '확인',
            barrierDismissible: false,
          )
        : _navigationService.navigateToView(const AddressSelectView());
    notifyListeners();
  }

  bool get isPhoneNumberAndNameExisted =>
      (_userProviderService.user!.name != null &&
          _userProviderService.user!.phoneNumber != null &&
          _userProviderService.user!.name != '' &&
          _userProviderService.user!.phoneNumber != '');

  bool get isPossibleToPurchase {
    if (isOffineMode == true && finalPrice >= 1000) return true;
    return (selectedAddress != null) &&
        isPhoneNumberAndNameExisted &&
        !impossibleToBuyBasedOnLocation &&
        finalPrice >= 1000;
  }

  //Onpressed On order
  String get purchaseButtonMessage {
    if (isOffineMode == true) {
      if (finalPrice < 1000) {
        return "최소 금액은 1000원 이상입니다";
      } else {
        return "결제하기";
      }
    }
    if (selectedAddress == null) {
      return "상단에서 배송지를 입력해주세요";
    } else if (impossibleToBuyBasedOnLocation) {
      return "배송이 불가능한 지역입니다";
    } else if (!isPhoneNumberAndNameExisted) {
      return "주문자 정보를 입력해주세요";
    } else if (finalPrice < 1000) {
      return "최소 금액은 1000원 이상입니다";
    } else {
      return "결제하기";
    }
  }

  Future<void> onPressedOnPayment() async {
    List<String> runOutItemNamesList = [];
    for (var item in cart.items!) {
      if (item.quantity > item.inventory.inventory) {
        runOutItemNamesList.add(item.inventory.product.name);
      }
    }
    if (runOutItemNamesList.isNotEmpty) {
      print(runOutItemNamesList.toString());
      String nameList = runOutItemNamesList.toString();
      _dialogService.showDialog(
          title: '재고 부족',
          description:
              '${nameList.substring(1, nameList.length - 1)} 재고가 부족합니다',
          buttonTitle: '확인');
      return;
    }

    String result = await _navigationService.navigateWithTransition(
        PurchaseOptionView(
          orderName:
              "${cart.items![0].inventory.product.name} 포함 ${cart.items!.length}건에 대한 주문",
          amount: finalPrice,
          address: selectedAddress!,
          orderRequestMessage: _cartProviderService.orderRequestMessage,
          bookingOrderMessage: bookingOrderMessage,
          option: isOffineMode
              ? "inStore"
              : takeOut
                  ? 'takeOut'
                  : 'delivery',
        ),
        transition: 'fade');
    if (result == null) {
      _dialogService.showCustomDialog(
          title: '취소', description: '결제를 취소하셨습니다', mainButtonTitle: '확인');
      return;
    }

    String orderId =
        "${_userProviderService.user!.id}_${DateTime.now().millisecondsSinceEpoch}";
    await _navigationService.navigateWithTransition(
        PurchaseView(
            paymentData: PaymentData.fromJson({
              'pg': result,
              'payMethod': result == 'kakaopay' ? 'kakaopay' : 'card',
              'name':
                  "${cart.items![0].inventory.product.name} 포함 ${cart.items!.length}건에 대한 주문",
              'amount': finalPrice,
              // 'amount': 10,
              'customData': {
                "option": isOffineMode
                    ? "inStore"
                    : takeOut
                        ? "takeOut"
                        : "delivery",
                "storeAddress": _storeProviderService.store!.address ?? '',
                "bookingOrderMessage": bookingOrderMessage ?? '',
                "orderRequestMessage":
                    _cartProviderService.orderRequestMessage ?? '',
                "customerId": _userProviderService.user!.id,
                "cartId": cart.id,
                "items": describeItems(),
              },
              'merchantUid': orderId,
              'buyerName': _userProviderService.user!.name,
              'buyerTel': _userProviderService.user!.phoneNumber,
              'buyerEmail': _userProviderService.user!.email,
              'buyerAddr':
                  "${selectedAddress!.address} ${selectedAddress?.addressDetail ?? ""}",
              'buyerPostcode': selectedAddress!.postcode,
              'appScheme': "livFarm",
              'display': {
                'cardQuota': [2, 3] //결제창 UI 내 할부개월수 제한
              }
            }),
            order: Order(
                isReviewed: false,
                id: orderId,
                orderTitle:
                    "${cart.items![0].inventory.product.name} 포함 ${cart.items!.length}건에 대한 주문",
                status: 0,
                option: isOffineMode
                    ? "inStore"
                    : takeOut
                        ? "takeOut"
                        : "delivery",
                bookingOrderMessage: bookingOrderMessage,
                address: selectedAddress!,
                createdAt: DateTime.now(),
                cart: cart,
                storeId: cart.storeId!,
                paidAmount: finalPrice,
                user: _userProviderService.user!,
                payMethod: "card",
                usedPoint:
                    (pointInput == 0 || isInputPointAmountExceedDiscountedPrice)
                        ? 0
                        : pointInput,
                scheduledDate: _cartProviderService.bookingOrderDateTime!,
                orderRequestMessage: _cartProviderService.orderRequestMessage,
                coupon: (selectedCoupon == null ||
                        isCouponAmountExceedDiscountedPrice)
                    ? null
                    : selectedCoupon)),
        transition: 'fade');
    notifyListeners();
  }

  String describeItems() {
    String description = '';
    for (Item item in cart.items!) {
      description += item.inventory.product.name;
      description += " ${item.quantity} ,";
    }
    return description;
  }
}
