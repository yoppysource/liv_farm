// const hostIP = "34.64.111.112";
const hostIP = "yoppysource.ap.ngrok.io";

const hostPORT = 80;
const scheme = 'http';
const basePATH = "api/v1";

String valueForJWT(String jwt) => "Bearer $jwt";
const String kakaoClientId = "ac5068208cf1f0bb6197f66f62278038";
const String kakaoJSClientId = "ace10611f290b696eaae9939138256b4";
const String KEY_JWT = "jwt";
const String KEY_IamPort = 'imp87654969';
const String KEY_STORE = 'store';
