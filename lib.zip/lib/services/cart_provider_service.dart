import 'package:liv_farm/app/app.locator.dart';
import 'package:liv_farm/model/cart.dart';
import 'package:liv_farm/model/coupon.dart';
import 'package:liv_farm/services/server_service/client_service.dart';

import 'package:observable_ish/observable_ish.dart';
import 'package:stacked/stacked.dart';

class CartProviderService extends BaseViewModel with ReactiveServiceMixin {
  CartProviderService() {
    listenToReactiveValues([_cart]);
  }
  final RxValue<Cart?> _cart = RxValue<Cart?>(null);
  Cart? get cart => _cart.value;
  String get bottomNavigationBarItemText =>
      _cart.value == null ? '0' : _cart.value!.items.length.toString();

  Coupon? selectedCoupon;
  DateTime? bookingOrderDateTime;
  bool takeout = false;
  String orderRequestMessage = '';
  // String deliveryReservationMessage = '';
  final ClientService _serverService = locator<ClientService>();

  void syncCartFromInstance(Cart cart) {
    _cart.value = cart;
    notifyListeners();
  }

  void syncCartFromJson(Map<String, dynamic> data) {
    _cart.value = Cart.fromJson(data);
    notifyListeners();
  }

  Future<void> syncCartFromServer() async {
    Map<String, dynamic> cart = await _serverService.sendRequest(
        method: HttpMethod.get, resource: Resource.carts, endPath: '/my');
    syncCartFromJson(cart);
  }

  Future<void> updateCartWhenStoreSet(String storeId) async {
    if (cart != null && cart!.storeId != storeId) {
      Map<String, dynamic> cart = await _serverService.sendRequest(
          method: HttpMethod.patch,
          resource: Resource.carts,
          endPath: '/my',
          data: {'store': storeId});
      syncCartFromJson(cart);
    }
  }

  void resetCart() {
    bookingOrderDateTime = null;
    orderRequestMessage = '';
    // deliveryReservationMessage = '';
    selectedCoupon = null;
    _cart.value!.items = [];
    notifyListeners();
  }
}
