import 'package:liv_farm/model/product.dart';

class Inventory {
  late final int inventory;
  late final int rank;
  late final bool isOnShelf;
  late final bool hidden;
  late final String store;
  late final Product product;
  late final String id;

  Inventory(
      {required this.inventory,
      required this.rank,
      required this.isOnShelf,
      required this.hidden,
      required this.store,
      required this.product,
      required this.id});

  Inventory.fromJson(Map<String, dynamic> json) {
    inventory = json['inventory'];
    rank = json['rank'];
    isOnShelf = json['isOnShelf'];
    hidden = json['hidden'];
    store = json['store'];
    product = Product.fromJson(json['product']);
    id = json['id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['inventory'] = inventory;
    data['rank'] = rank;
    data['isOnShelf'] = isOnShelf;
    data['hidden'] = hidden;
    data['store'] = store;
    data['product'] = product.toJson();
    data['id'] = id;
    return data;
  }
}
