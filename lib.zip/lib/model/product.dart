import 'package:liv_farm/model/review.dart';
import 'package:liv_farm/secret.dart';
import 'package:liv_farm/util/category_enum.dart';

class Product {
  late final double ratingsAverage;
  late final int ratingsQuantity;
  late final String name;
  late final int category;
  late final int price;
  late final String location;
  late final String nameInEng;
  late final String intro;
  late final List<Review>? reviews;
  late final String id;
  late final String descriptionImgPath;
  late final String thumbnailPath;
  late final List detailImgPath;
  late final String weight;
  late final int? discountedPrice;

  Product({
    required this.ratingsAverage,
    required this.ratingsQuantity,
    required this.name,
    required this.category,
    required this.nameInEng,
    required this.price,
    required this.location,
    this.reviews,
    required this.intro,
    required this.id,
    required this.descriptionImgPath,
    required this.thumbnailPath,
    required this.detailImgPath,
    required this.weight,
    required this.discountedPrice,
  });

  Product.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    ratingsAverage = json['ratingsAverage']?.toDouble() ?? 4.5;
    ratingsQuantity = json['ratingsQuantity'] ?? 0;

    category = json['category'];
    name = json['name'];
    nameInEng = json['nameInEng'];
    price = json['price'];
    discountedPrice = json['discountedPrice'] ?? json['price'];
    location = json['location'];
    intro = json['intro'];
    descriptionImgPath =
        Uri(scheme: scheme, port: hostPORT, host: hostIP).toString() +
            json['descriptionImgPath'];
    thumbnailPath =
        Uri(scheme: scheme, port: hostPORT, host: hostIP).toString() +
            json['thumbnailPath'];
    detailImgPath = json['detailImgPath']
            ?.map((e) =>
                Uri(
                  scheme: scheme,
                  port: hostPORT,
                  host: hostIP,
                ).toString() +
                e)
            ?.toList() ??
        <String>[];
    weight = json['weight'];
    if (json['reviews'] != null && json['reviews'].isNotEmpty) {
      reviews = [];
      json['reviews'].forEach((v) {
        reviews!.add(Review.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    return data;
  }
}

extension ProductExtension on Product {
  ProductCategory get productCategory => ProductCategory.values[category];
}
