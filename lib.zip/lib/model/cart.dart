import 'package:liv_farm/model/inventory.dart';

class Cart {
  late final List<Item> items;
  late final int totalPrice;
  late final int? totalDiscountedPrice;
  late final String id;
  String? storeId;

  Cart(
      {required this.items,
      required this.totalPrice,
      required this.totalDiscountedPrice,
      required this.id,
      required this.storeId});

  Cart.fromJson(Map<String, dynamic> json) {
    print(json);
    if (json['items'] != null) {
      items = [];
      json['items'].forEach((v) {
        items.add(Item.fromJson(v));
      });
    }
    if (storeId != null) storeId = json['storeId'];
    totalPrice = json['totalPrice'];
    totalDiscountedPrice = json['totalDiscountedPrice'];
    id = json['id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (items.isNotEmpty) {
      data['items'] = items.map((v) => v.toJson()).toList();
    }
    data['storeId'] = storeId;

    data['totalPrice'] = totalPrice;
    data['totalDiscountedPrice'] = totalDiscountedPrice ?? 0;
    data['id'] = id;
    return data;
  }
}

class Item {
  late final int quantity;
  late final String id;
  late final Inventory inventory;

  Item({required this.quantity, required this.id, required this.inventory});

  Item.fromJson(Map<String, dynamic> json) {
    quantity = json['quantity'];
    id = json['id'];
    inventory = Inventory.fromJson(json['inventory']);
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['quantity'] = quantity;
    data['id'] = id;
    return data;
  }
}
